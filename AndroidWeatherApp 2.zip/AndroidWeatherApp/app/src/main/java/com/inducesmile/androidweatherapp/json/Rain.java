package com.inducesmile.androidweatherapp.json;


public class Rain {

    private String h;

    public Rain(String h) {
        this.h = h;
    }

    public String getH() {
        return h;
    }
}
